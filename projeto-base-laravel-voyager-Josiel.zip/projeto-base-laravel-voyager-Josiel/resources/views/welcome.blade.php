@extends('layouts.app')

@section('conteudo')
    @includeIf('componentes.header')
    @includeIf('componentes.assets')
    @includeIf('componentes.services')
    @includeIf('componentes.about')
    @includeIf('componentes.team')
    @includeIf('componentes.clients')
    @includeIf('componentes.contact')
@endsection
