<header class="masthead">
    <div class="container">
        <div class="masthead-subheading">
           <?php echo e(setting('site.title')); ?>

        </div>
        <div class="masthead-heading text-uppercase">
            <?php echo e(setting('site.description')); ?>

        </div>
        <a class="btn btn-primary btn-xl text-uppercase" href="#services">
            Conheça a aplicação
        </a>
    </div>
</header>
<?php /**PATH D:\projeto-base-laravel-voyager\resources\views/componentes/header.blade.php ENDPATH**/ ?>